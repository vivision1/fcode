#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Requires Python 3.6 or later

import XiteWin

if __name__ == "__main__":
	XiteWin.main("")
